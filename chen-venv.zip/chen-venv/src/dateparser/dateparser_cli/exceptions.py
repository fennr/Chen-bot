class FastTextModelNotFoundException(Exception):
    pass
